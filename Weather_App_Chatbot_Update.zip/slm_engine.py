from pathlib import Path
from collections import OrderedDict
import io, pickle, zipfile
import numpy as np

BASE = Path(__file__).resolve().parent / "model"
with open(BASE / "tiny_slm_vocab.pkl", "rb") as file:
    vocab = pickle.load(file)
stoi, itos = vocab["stoi"], vocab["itos"]
block_size, n_layer, n_head = vocab["block_size"], vocab["n_layer"], vocab["n_head"]


class _Storage: pass
class _SafeTorchUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if module == "collections" and name == "OrderedDict": return OrderedDict
        if module == "torch" and name.endswith("Storage"): return _Storage
        if module == "torch._utils" and name == "_rebuild_tensor_v2":
            return lambda storage, offset, size, stride, requires_grad, hooks: (storage, offset, size, stride)
        raise pickle.UnpicklingError(f"Unsupported checkpoint object: {module}.{name}")
    def persistent_load(self, value): return value


def _load_weights(path):
    with zipfile.ZipFile(path) as archive:
        root = archive.namelist()[0].split("/", 1)[0]
        metadata = _SafeTorchUnpickler(io.BytesIO(archive.read(f"{root}/data.pkl"))).load()
        weights = {}
        for name, (storage, offset, shape, stride) in metadata.items():
            key = storage[2]
            raw = archive.read(f"{root}/data/{key}")
            flat = np.frombuffer(raw, dtype="<f4")
            if tuple(stride) == tuple(np.cumprod((1,) + tuple(shape[:0:-1]))[::-1]):
                array = flat[offset:offset+int(np.prod(shape))].reshape(shape)
            else:
                byte_strides = tuple(int(x)*4 for x in stride)
                array = np.lib.stride_tricks.as_strided(flat[offset:], shape=shape, strides=byte_strides).copy()
            weights[name] = array
        return weights


W = _load_weights(BASE / "tiny_slm.pt")
def linear(x, prefix): return x @ W[prefix+".weight"].T + W.get(prefix+".bias", 0)
def layer_norm(x, prefix):
    normalized = (x-x.mean(-1,keepdims=True))/np.sqrt(x.var(-1,keepdims=True)+1e-5)
    return normalized*W[prefix+".weight"]+W[prefix+".bias"]
def relu(x): return np.maximum(x,0)
def softmax(x):
    value=np.exp(x-np.max(x,axis=-1,keepdims=True)); return value/value.sum(axis=-1,keepdims=True)


def forward(tokens):
    x=W["token_embedding_table.weight"][tokens]+W["position_embedding_table.weight"][np.arange(len(tokens))]
    for layer in range(n_layer):
        base=f"blocks.{layer}"
        source=layer_norm(x,base+".ln1"); heads=[]
        for head in range(n_head):
            hp=f"{base}.sa.heads.{head}"
            key,query,value=(linear(source,hp+suffix) for suffix in (".key",".query",".value"))
            scores=query@key.T/(source.shape[-1]**.5)
            scores[np.triu_indices(len(tokens),1)]=-np.inf
            heads.append(softmax(scores)@value)
        x=x+linear(np.concatenate(heads,axis=-1),base+".sa.proj")
        source=layer_norm(x,base+".ln2")
        x=x+linear(relu(linear(source,base+".ffwd.net.0")),base+".ffwd.net.2")
    return linear(layer_norm(x,"ln_f"),"lm_head")


def generate_reply(message, count=120):
    tokens=[stoi[c] for c in message if c in stoi] or [stoi.get(" ",0)]
    prompt_length=len(tokens); rng=np.random.default_rng()
    for _ in range(count):
        context=tokens[-block_size:]; logits=forward(context)[-1]/.8
        keep=np.argpartition(logits,-min(40,len(logits)))[-min(40,len(logits)):]
        probs=softmax(logits[keep]); tokens.append(int(rng.choice(keep,p=probs)))
    text="".join(itos[i] for i in tokens[prompt_length:]).split("<|end|>",1)[0].strip()
    return text or "I could not create a reply. Please try another prompt."
